# Getting Started with homy

This guide will walk you through writing your first program in homy.

*(More documentation to come)*